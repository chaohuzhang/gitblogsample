---
layout: "about"
title: "About"
date: 2018-08-21 04:48:33
description: "Wish for the Best, Prepare for the Worst"
header-img: "img/header_img/about-bg.jpg"
comments: true
---

> Begin with a full stack soft engineer, then a machine learning engineer, now a frontend engineer!
> A girl still have colorful dream.
